package raytracing;

/**
 * <p>Title: Scene</p>
 * <p>Description: </p>
 * Klasa predstvlja scenu kod modela crtanja slike pomocu ray tracinga. Sastoji
 * se od izvora svjetlosti i konacnog broja objekata.
 * <p>Copyright: Copyright (c) 2003</p>
 * @author Milenka Gadze, Miran Mosmondor
 * @version 1.1
 */

import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
import java.awt.event.*;

public class Scene {

  final int MAXDEPTH=5; //maksimalna dubina rekurzije
  private int numberOfObjects;
  private Sphere[] sphere;
  private Point lightPosition;
  private ColorVector backroundColors=new ColorVector(0, 0, 0);
  private ColorVector light=new ColorVector((float)1 , (float)1,(float)1);
  private ColorVector ambientLight=new ColorVector((float)0.5, (float)0.5, (float)0.5);

  /**
   * Inicijalni konstruktor koji postavlja poziciju svijetla i parametre svih
   * objekata u sceni.
   *
   * @param lightPosition pozicija svijetla
   * @param numberOfObjects broj objekata u sceni
   * @param sphereParameters parametri svih kugli
   */
  public Scene(Point lightPosition, int numberOfObjects, SphereParameters[] sphereParameters) {
    this.lightPosition=lightPosition;
    this.numberOfObjects=numberOfObjects;
    sphere=new Sphere[numberOfObjects];
    for (int i=0; i<numberOfObjects; i++) {
      sphere[i]=new Sphere(sphereParameters[i]);
    }
  }

  /**
   * Metoda provjerava da li postoji sjena na tocki presjeka. Vraca true ako
   * se zraka od mjesta presjeka prema izvoru svjetlosti sjece s nekim objektom.
   *
   * @param intersection tocka presjeka
   * @return true ako postoji sjena u tocki presjeka, false ako ne postoji
   */
  private boolean shadow(Point intersection) {
	Ray line = new Ray(intersection, this.lightPosition);
	for (int i = 0; i < this.numberOfObjects; ++i) {
		if (this.sphere[i].intersection(line)) return true;
	}
    return false;
  }

  /**
   * Metoda koja pomocu pracenja zrake racuna boju u tocki presjeka. Racuna se
   * osvjetljenje u tocki presjeka te se zbraja s doprinosima osvjetljenja koje
   * donosi reflektirana i refraktirana zraka.
   *
   * @param ray pracena zraka
   * @param depth dubina rekurzije
   * @return vektor boje u tocki presjeka
   */
  public ColorVector traceRay(Ray ray, int depth) {
    boolean presjek = false;
	int najbliziPresjek = -1;
	//kraj rekurzije
	if (depth > this.MAXDEPTH) return new ColorVector(0, 0, 0);
    
	//pronalazak najblizeg presjeka (indeks)
	for (int i = 0; i < this.numberOfObjects; ++i) {
    	if (sphere[i].intersection(ray)) {
    		presjek = true;
    		if (najbliziPresjek != -1) {
    			Point startingPoint = ray.getStartingPoint();
    			double trenutno = startingPoint.getDistanceFrom(sphere[najbliziPresjek].getIntersectionPoint());
    			double kandidat = startingPoint.getDistanceFrom(sphere[i].getIntersectionPoint());
    			if (kandidat < trenutno) {
    				najbliziPresjek = i;
    			}
    		} else {
    			najbliziPresjek = i;
    		}
    	}
    }
	//ako nema presjeka vraca boju pozadine
    if (!presjek) return new ColorVector(backroundColors.getRed(),backroundColors.getGreen(), backroundColors.getBlue());
   	
    //ako ima presjeka
    else {
   		//za prikaz sjene
   		//return new ColorVector(1, 0, 1);
   		
   		double r, g, b, skalarni;
   		boolean shadow_val;
   		ColorVector C = new ColorVector(0, 0, 0);
 
   		//ambijentna komponenta
  		PropertyVector ka = sphere[najbliziPresjek].ka;
   		r = ambientLight.getRed() * ka.getRedParameter();
   		g = ambientLight.getGreen() * ka.getGreenParameter();
   		b = ambientLight.getBlue() * ka.getBlueParameter();
   		ColorVector Clocal = new ColorVector((float)r, (float)g, (float)b);
   		
   		//difuzna komponenta
  		PropertyVector kd = sphere[najbliziPresjek].kd;
   		Point najbliza = sphere[najbliziPresjek].getIntersectionPoint();
   		shadow_val = shadow(najbliza); //provjera je li u sjeni
   		Vector L = new Vector(najbliza, lightPosition);
   		L.normalize();
   		Vector N = sphere[najbliziPresjek].getNormal(najbliza);
   		N.normalize();
   		skalarni = L.dotProduct(N);
   		if (skalarni > 0 && !shadow_val) {
   			r = light.getRed() * kd.getRedParameter() * skalarni;
   			g = light.getGreen() * kd.getGreenParameter() * skalarni;
   			b = light.getBlue() * kd.getBlueParameter() * skalarni;
   			ColorVector Cd = new ColorVector((float)r, (float)g, (float)b);
   			Clocal = Clocal.add(Cd);
   		}
   		
   		//spekularna komponenta
   		PropertyVector ks = sphere[najbliziPresjek].ks;
   		Vector V = new Vector(najbliza, ray.getStartingPoint()); 
   		V.normalize();
	  	Vector R = L.getReflectedVector(N);
   		R.normalize();
   		skalarni = R.dotProduct(V);
   		if (skalarni > 0 && !shadow_val) {
   			float potencija = sphere[najbliziPresjek].getN();
   			r = light.getRed() * ks.getRedParameter() * Math.pow(skalarni, potencija);
   			g = light.getGreen() * ks.getGreenParameter() * Math.pow(skalarni, potencija);
   			b = light.getBlue() * ks.getBlueParameter() * Math.pow(skalarni, potencija);
   			ColorVector Cd = new ColorVector((float)r, (float)g, (float)b);
   			Clocal = Clocal.add(Cd);
   		}
   		C = C.add(Clocal);
   		
   		//reflektirana zraka
   		Vector refleksija = V.getReflectedVector(N);
   		refleksija.normalize();
   		Ray Refl = new Ray(najbliza, refleksija);
   		ColorVector Crefl = traceRay(Refl, depth + 1);
   		C = C.add(Crefl.multiple(sphere[najbliziPresjek].getReflectionFactor()));
   		
   		//refraktirana zraka
   		double ni = sphere[najbliziPresjek].getNi();
   		double VN = V.dotProduct(N);
   		if (VN < 0) {
   			N = N.multiple(-1);
   			ni = (float) 1 / ni;
   		}
   		Vector refrakcija = V.getRefractedVector(N, ni);
   		refrakcija.normalize();
   		Ray Refr = new Ray(najbliza, refrakcija);
   		ColorVector Crefr = traceRay(Refr, depth + 1);
   		C = C.add(Crefr.multiple(sphere[najbliziPresjek].getRefractionFactor()));
   		
   		//korekcija RGB komponenti
   		C.correct();
   		return C;
   	}
  }
}